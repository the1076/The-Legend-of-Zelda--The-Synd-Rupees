/*

IMPORTANT STUFF

This Construct 2 mini-plugin for Chrome fanatics (like me!) let's you log things to the JavaScript console.

!!!This is not an official Google Chrome plugin!!!
!!!This is not an official Scirra or Construct 2 plugin!!!

It's just something quick I made out of necessity. It probably has bugs. We are not
guaranteeing that it will work, or that we will fix it.

DEMO

A live demo that shows the plugin in action can be seen at:
http://www.funstormgames.com/blog/construct-2-log-to-chrome-console-plugin

DOWNLOAD & INSTALLATION

Download from: http://www.funstormgames.com/blog/construct-2-log-to-chrome-console-plugin
Copy the 'playtomic' folder to '<you Construct 2 install directory>\exporters\html5\plugins'.
Then you can use the plugin from within Construct 2.

TUTORIAL

1) Add a Chrome Console object to your Construct 2 project
2) Press Ctrl+Shift+J to bring up the JavaScript console or select Wrench->Tools->JavaScript Console
3) To log numbers or text add action -> Chrome Console -> Log Text
4) To log objects add action -> Chrome Console -> Log Object

LICENSE

This plugin has no license. Do whatever you want with it... use commerically, modify,
redistribute, etcetcetc. You don't have to, but it would be nice if you included
somewhere that you got it from:

http://www.funstormgames.com/

QUESTIONS, COMMENTS, FEEDBACK, BUGS

Please let me know if you find a bug and I will do my best to fix it.

*/